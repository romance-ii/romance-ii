package com.paypal.sdk.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.paypal.soap.api.ErrorType;

public class ObjectIterator {
    
	public Map objectFields = new HashMap();

	public Map getFieldMap(Object object) throws Exception {
		Method[] methodArray = getAllMethods(object);
		putInMap(methodArray, object);
		return objectFields;
	}

	private String getName(String name) {
		String newName = "";
		if (name.indexOf("get") == 0) {
			newName = name.substring(3).toUpperCase();
		}
		return newName;
	}

	private void putInMap(Method[] methodArray, Object obj) throws Exception {

		for (Method method : methodArray) {

			try {
				try {
					if (method.getReturnType().getDeclaredMethod("getValue",
							null).getReturnType().getName() == "org.apache.axis.types.Token") {
						if (method.invoke(obj, null) != null) {
							objectFields.put(getName(method.getName()), method
									.getReturnType().getDeclaredMethod(
											"getValue", null).invoke(
											method.invoke(obj, null), null));
						}
					}
					continue;
				} catch (NoSuchMethodException nm) {
				}
				if(method.getReturnType().getName().equalsIgnoreCase("Token")){
					objectFields.put(getName(method.getName()), method
							.invoke(obj, null));
				}
				if (method.getReturnType().getName().equalsIgnoreCase(
						"java.util.Calendar")) {
					if (method.invoke(obj, null) != null) {
						objectFields.put(getName(method.getName()),
								((GregorianCalendar) method.invoke(obj, null))
										.getTime());
					}
				} else if (method.getName().equalsIgnoreCase("toString")
						|| method.getName().equalsIgnoreCase("hashCode")) {
					// Do nothing
				} else if (method.getReturnType().isPrimitive()
						|| method.getReturnType().getName().equalsIgnoreCase(
								"java.lang.Integer")
						|| method.getReturnType().isInstance(new String())) {
					if ((method.invoke(obj, null) != null) & (!"".equalsIgnoreCase(String.valueOf(method.invoke(obj, null))))) {
						objectFields.put(getName(method.getName()), method
								.invoke(obj, null));
					}
				} else if (method.getReturnType().isArray() && 
						method.getReturnType()== com.paypal.soap.api.ErrorType[].class) {
					Object object = method.invoke(obj, null);
					if (object != null) {
						int i=0;
					    ErrorType[] errors =(ErrorType[])object;
					    for(ErrorType error:errors){
					    	objectFields.put("L_SHORTMESSAGE"+i, error.getShortMessage());
					    	objectFields.put("L_LONGMESSAGE"+i, error.getLongMessage());
					    	objectFields.put("L_ERRORCODE"+i, error.getErrorCode());
					    	
					    	i++;
					    }
					}
				} else {
					Object object = method.invoke(obj, null);
					if (object == null) {
						continue;
					}
					Method[] methods = getAllMethods(object);
					putInMap(methods, object);
				}

			} catch (NoSuchMethodException nm) {
				// log.debug(nm.toString());
			} catch (InstantiationException ie) {
				// log.debug(ie.toString());
			} catch (IllegalArgumentException iae) {
				// log.debug(iae.toString());
			} catch (IllegalAccessException ia) {
				// log.debug(ia.toString());
			}
		}
	}

	private Method[] getAllMethods(Object object) {
		Class clazz = object.getClass();
		List<Method> methodList = new ArrayList<Method>();
		Method[] methods = null;
		methods = clazz.getMethods();
		Set<String> paramSet = getParameterTypes(clazz);

		for (Method method : methods) {
			if (paramSet.contains(method.getReturnType().getName())) {
				methodList.add(method);
			}
		}
		return (Method[]) methodList.toArray(new Method[methodList.size()]);
	}

	private Set getParameterTypes(Class clazz) {
		Set<String> param = new HashSet<String>();
		Constructor[] constructors = clazz.getDeclaredConstructors();

		for (Constructor constructor : constructors) {
			constructor.setAccessible(true);
			Class[] paramTypes = constructor.getParameterTypes();
			for (Class cls : paramTypes) {
				param.add(cls.getName());
			}
		}
		return param;
	}

}
