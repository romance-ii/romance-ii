SDK Seller Credentials (sandbox and beta-sandbox)
=================================================

API User Name	: sdk-seller_api1.sdk.com
API Password	: 12345678

PEM File	: sdk-seller_cert_key_pem.txt (public certificate and private key)
PEM File	: sdk-seller.pem (private key)

PKCS12 File	: sdk-seller.p12
PKCS12 Passowrd : password